# Wan2.2-TI2V-5B VAE patch-parallel scaling (8x H20)

VAE `decode` latency vs patch-parallel degree. `native` = the served single-GPU
non-tiled decode (the real baseline); `tiled_ppN` = distributed tiled decode over
N ranks. PP=1/2/4 were profiled earlier (<=4 GPUs); PP=8 is the new 8-GPU point.
Median ms over bench iters, per (H,W,F) Wan video shape.

| shape HxWxF | native | tiled_pp1 | tiled_pp2 | tiled_pp4 | tiled_pp8 |
|---|---|---|---|---|---|
| 480x832x81 | 5806 | 13463 | 6849 | 3549 | 1868 |
| 720x1280x49 | 7869 | 17993 | 9104 | 4756 | 2463 |
| 720x1280x81 | 12992 | 29589 | 14916 | 7841 | 4011 |

## Speedup vs native single-GPU decode

| shape HxWxF | tiled_pp1 | tiled_pp2 | tiled_pp4 | tiled_pp8 |
|---|---|---|---|---|
| 480x832x81 | 0.43x | 0.85x | 1.64x | 3.11x |
| 720x1280x49 | 0.44x | 0.86x | 1.65x | 3.20x |
| 720x1280x81 | 0.44x | 0.87x | 1.66x | 3.24x |
