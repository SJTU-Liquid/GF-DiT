# VAE patch-parallel (tiled) profiling bundle -- COMPLETE (incl 8-GPU/PP8)

Wan2.2-TI2V-5B VAE decode, 8x H20. native vs tiled PP1/2/4/8.
PP1/2/4 profiled on <=4 GPUs (out/vae); PP8 on 8 GPUs (out/vae_pp8).

## Files
- SUMMARY.md            : latency + speedup table (incl PP8 3.1-3.2x)
- results/*.json        : curated per-PP decode latency (native, tiled_pp1/2/4/8)
- raw_logs/             : raw profiling logs + raw JSON (le4gpu_sweep.log, pp8.log, run/chain.log)
- scripts/              : profiling driver(s)
- COMMIT.txt            : pinned commit
