# Legacy Baseline (pre-adaptive-serving, commit cf328eb)

Static SP=4 (ulysses=4, one group), FIFO, no runtime_v2 / no elastic lanes. 4x H20.
Server = cf328eb via PYTHONPATH worktree; bench = current-HEAD mixed_priority client (HTTP-only). See COMMIT.txt.
Wan runs use --guidance-scale 4.0 (true CFG) to match the runtime_v2 wan adapter's
default_guidance_scale=4.0; Qwen runs omit it (do_true_cfg=False both sides).

| run | done | SLO_all | S | M | L | p99 (s) | mean (s) | qps |
|---|---|---|---|---|---|---|---|---|
| Qwen short (tl1.20) | 127/127 | 13.4% | 3% | 19% | 64% | 687.2 | 322.7 | 0.102 |
| Qwen fg_burst (tl0.90) | 257/257 | 6.6% | 0% | 13% | 20% | 1308.6 | 740.0 | 0.089 |
| Qwen inflight (tl0.70) | 108/108 | 22.2% | 2% | - | 100% | 405.1 | 191.6 | 0.091 |
| Wan short (tl1.20) | 61/61 | 29.5% | 18% | 50% | 67% | 1459.4 | 610.9 | 0.024 |
| Wan fg_burst (tl1.10) | 65/65 | 21.5% | 0% | 31% | 71% | 1376.5 | 680.5 | 0.023 |
| Wan inflight (tl0.90) | 23/23 | 60.9% | 47% | - | 100% | 347.3 | 163.7 | 0.023 |

## Context: legacy SP4 vs new-runtime static SP4 vs best elastic (Qwen)

| profile | legacy SP4 | planB fcfs_sp4 | planB best |
|---|---|---|---|
| Qwen short | 13.4% | 12.6% | 83.5% edf_best_fit |
| Qwen fg_burst | 6.6% | 6.2% | 73.5% edf_greedy |
| Qwen inflight | 22.2% | 21.3% | 82.4% srtf_sp1 |

Legacy SP4 matches new-runtime static fcfs_sp4 across all three Qwen profiles
(13.4~=12.6, 6.6~=6.2, 22.2~=21.3): the runtime itself did not get faster; the
EDF/elastic gains are pure scheduling.

## Wan: CFG alignment (why the first attempt was invalid)

First Wan legacy attempt ran guidance=0.0 (no CFG) because the bench never sends
guidance and legacy's default is 0.0, while the runtime_v2 wan adapter falls back
to default_guidance_scale=4.0 (CFG on, 2 forward passes/step). That made legacy do
HALF the compute -> falsely better (Wan short 36.1% vs new-runtime fcfs_sp4 27.9%).
After injecting --guidance-scale 4.0, legacy does true CFG and aligns:
Wan short legacy 29.5% vs new-runtime fcfs_sp4 27.9% (1.6pp, same as the Qwen story).
