#!/bin/bash
# Fill in the 4 missing policies × 3 calibrated profiles on h20.
# planB so far has: edf_best_fit, edf_greedy, srtf_sp1, srtf_sp2 (4 policies).
# This run adds: srtf_sp4, fcfs_sp1, fcfs_sp2, fcfs_sp4.
set -uo pipefail
cd /home/LOCAL/shixuan/xinwei/vllm-omni-private

mkdir -p out/qwen_battery_planB

# h20-specific env (see CLAUDE.md / project_qwen_image_battery)
export LD_LIBRARY_PATH=""
export HF_HUB_OFFLINE=1

MODEL=Qwen/Qwen-Image \
TASK=t2i \
BENCH_BACKEND=openai \
SERVE_EXTRA_ARGS="" \
COST_MODEL_DIR=cost-model/qwen-image \
GPUS=4,5,6,7 \
NUM_GPUS=4 \
SP_SIZES=1,2,4 \
POLICIES="srtf_sp4 fcfs_sp1 fcfs_sp2 fcfs_sp4" \
WORKLOADS="out/stress/qwenbat_short_tl1.20_seed42.json out/stress/qwenbat_foreground_burst_tl0.90_seed42.json out/stress/qwenbat_inflight_burst_tl0.70_seed42.json" \
OUT_ROOT=out/qwen_battery_planB \
VENV_BIN=/home/LOCAL/shixuan/xinwei/.venv/bin \
SERVER_GREP="Qwen-Image" \
PORT=8098 \
BENCH_TIMEOUT=3600 \
  bash scripts/run_h20_battery.sh
