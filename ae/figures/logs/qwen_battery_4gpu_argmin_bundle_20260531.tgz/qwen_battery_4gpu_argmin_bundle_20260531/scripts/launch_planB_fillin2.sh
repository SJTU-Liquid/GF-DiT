#!/bin/bash
# Fill in the last 2 missing runs that died when the driver was killed mid-run:
#   inflight_burst_tl0.70 × {fcfs_sp2, fcfs_sp4}
# GPU set is now 3,4,5,6 (GPU3 hosts MPS daemon again, GPU7 reserved).
set -uo pipefail
cd /home/LOCAL/shixuan/xinwei/vllm-omni-private

mkdir -p out/qwen_battery_planB

export LD_LIBRARY_PATH=""
export HF_HUB_OFFLINE=1

MODEL=Qwen/Qwen-Image \
TASK=t2i \
BENCH_BACKEND=openai \
SERVE_EXTRA_ARGS="" \
COST_MODEL_DIR=cost-model/qwen-image \
GPUS=3,4,5,6 \
NUM_GPUS=4 \
SP_SIZES=1,2,4 \
POLICIES="fcfs_sp2" \
WORKLOADS="out/stress/qwenbat_inflight_burst_tl0.70_seed42.json" \
OUT_ROOT=out/qwen_battery_planB \
VENV_BIN=/home/LOCAL/shixuan/xinwei/.venv/bin \
SERVER_GREP="Qwen-Image" \
PORT=8098 \
BENCH_TIMEOUT=3600 \
  bash scripts/run_h20_battery.sh
