# Qwen-Image Scheduling Policy Battery (planB)

8 scheduling policies x 3 calibrated mixed-priority profiles, Qwen/Qwen-Image (20B DiT), 4x H20, elastic SP{1,2,4}.

Metric: per-class SLO attainment + overall. Cost model: h20-native (`cost-model/qwen-image`). See COMMIT.txt for pinned code.


## short_tl1.20  (S重 / 过载1.2)

| policy | SLO_all | S | M | L | p99 (s) | mean (s) | qps |
|---|---|---|---|---|---|---|---|
| edf_best_fit | 83.5% | 89% | 69% | 100% | 404.7 | 50.1 | 0.167 |
| edf_greedy | 82.7% | 88% | 69% | 100% | 401.0 | 49.8 | 0.167 |
| srtf_sp1 | 73.2% | 80% | 55% | 100% | 382.5 | 51.5 | 0.159 |
| srtf_sp2 | 37.0% | 39% | 36% | 27% | 720.6 | 120.1 | 0.126 |
| fcfs_sp1 | 28.3% | 11% | 40% | 100% | 238.2 | 99.4 | 0.159 |
| fcfs_sp2 | 21.3% | 7% | 29% | 91% | 459.9 | 209.3 | 0.126 |
| srtf_sp4 | 18.9% | 26% | 12% | 0% | 1078.2 | 302.6 | 0.092 |
| fcfs_sp4 | 12.6% | 3% | 17% | 64% | 840.7 | 381.4 | 0.092 |

**Winner: `edf_best_fit` (83.5%)**

## fg_burst_tl0.90  (前台突发)

| policy | SLO_all | S | M | L | p99 (s) | mean (s) | qps |
|---|---|---|---|---|---|---|---|
| edf_greedy | 73.5% | 80% | 68% | 59% | 551.1 | 95.7 | 0.141 |
| edf_best_fit | 73.2% | 80% | 66% | 59% | 552.2 | 96.5 | 0.141 |
| srtf_sp1 | 69.6% | 66% | 68% | 81% | 1208.6 | 97.1 | 0.140 |
| srtf_sp2 | 30.7% | 28% | 45% | 28% | 1375.6 | 193.1 | 0.105 |
| fcfs_sp1 | 23.3% | 0% | 13% | 100% | 437.4 | 261.1 | 0.132 |
| srtf_sp4 | 9.3% | 10% | 13% | 6% | 1473.4 | 357.0 | 0.064 |
| fcfs_sp2 | 6.6% | 0% | 4% | 28% | 1056.4 | 612.0 | 0.098 |
| fcfs_sp4 | 6.2% | 0% | 13% | 19% | 1472.2 | 743.5 | 0.052 |

**Winner: `edf_greedy` (73.5%)**

## inflight_burst_tl0.70  (在飞L突发(无M类))

| policy | SLO_all | S | M | L | p99 (s) | mean (s) | qps |
|---|---|---|---|---|---|---|---|
| srtf_sp1 | 82.4% | 78% | - | 100% | 227.5 | 35.6 | 0.137 |
| edf_best_fit | 51.9% | 40% | - | 100% | 199.2 | 34.5 | 0.137 |
| edf_greedy | 40.7% | 26% | - | 100% | 193.6 | 36.2 | 0.137 |
| fcfs_sp1 | 29.6% | 12% | - | 100% | 231.4 | 74.0 | 0.123 |
| srtf_sp2 | 26.9% | 8% | - | 100% | 369.7 | 119.6 | 0.108 |
| srtf_sp4 | 23.1% | 3% | - | 100% | 769.2 | 324.4 | 0.074 |
| fcfs_sp4 | 21.3% | 1% | - | 100% | 694.2 | 309.8 | 0.073 |
| fcfs_sp2 | 16.7% | 0% | - | 82% | 1358.7 | 869.8 | 0.050 |

**Winner: `srtf_sp1` (82.4%)**

---

# UPDATE 2026-05-31 — edf_best_fit re-run with argmin doomed-fallback fix (clean GPUs)

The `edf_best_fit` results in this bundle have been **replaced** with a re-run on
clean GPUs (h20 GPUs 4,5,6,7, no external contention) using the fixed
`_best_fit_sp` doomed-request fallback. All baselines (edf_greedy, srtf_*, fcfs_*)
are unchanged from the original planB run.

**The fix:** when no SP size can meet a request's deadline (request is "doomed"),
the old code returned the *largest* SP (`candidates[-1]`). For a doomed small (S)
request under overload this is pure negative optimization on Qwen-Image (wider SP
is same/slower for small latents) AND it hogs 4 ranks a still-meetable request
could use. Fixed to return the SP that **finishes soonest** per the cost model
(`argmin _estimate_finish_ms`): S -> SP1 (narrow fastest for small), L -> SP4
(wide fastest for large).

## edf_best_fit SLO: old (largest-fit) vs new (argmin)

| workload            | OLD edf_best | NEW edf_best (argmin) | Δ        | new per-class      |
|---------------------|-------------:|----------------------:|---------:|--------------------|
| short_tl1.20        | 83.5%        | **84.3%**             | +0.8pp   | S89 / M71 / L100   |
| foreground_burst_0.90 | 73.2%      | **72.8%**             | −0.4pp   | S80 / M64 / L59    |
| inflight_burst_0.70 | 51.9%        | **80.6%**             | **+28.7pp** | S76 / L100      |

**Takeaway:** the fix is neutral on short/foreground (those profiles rarely trigger
the doomed fallback) and a large win on inflight_burst (+28.7pp), entirely via the
S class (40% → 76%) — exactly the overload regime where the bug bit. Benchmark
durations matched the old run (759 vs 762s short; 1822 vs 1817s fg), confirming
clean/comparable GPU conditions, so the inflight gain is a pure policy improvement.

**Provenance:** edf_best_fit re-run via `scripts/run_h20_battery.sh`
(NUM_GPUS=4, GPUS=4,5,6,7, SP_SIZES=1,2,4, GFC_AUTOTUNE elastic4,
COST_MODEL_DIR=cost-model/qwen-image, patched bench with per-request dump).
The argmin doomed-fallback fix is in `_best_fit_sp` of both
`vllm_omni/diffusion/runtime_v2/policies/edf_best_fit.py` and
`benchmarks/diffusion/policies/edf_best_fit.py` (NOT yet committed as of this bundle;
base commit f70a94f).
