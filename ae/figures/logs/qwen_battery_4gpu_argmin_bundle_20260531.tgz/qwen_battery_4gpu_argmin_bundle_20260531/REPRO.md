# Reproduction

## Pinned code
See `COMMIT.txt`. Checkout that exact commit before running:
```
git checkout <COMMIT from COMMIT.txt>
```

## Hardware / env (h20)
- 4x H20, CUDA_VISIBLE_DEVICES=4,5,6,7 (avoid GPU3 = MPS)
- MUST clear LD_LIBRARY_PATH (system cuda-12.8 shadows venv) and set HF_HUB_OFFLINE=1
- venv: /home/LOCAL/shixuan/xinwei/.venv

## Cost model
`cost-model/qwen-image/` (tp1_ulysses{1,2,4}_ring1_cfg1.json) — h20-native fit from
`benchmarks/diffusion/runtime_v2_stage_profiler.py --adapter qwen`.

## Workloads
`workloads/qwenbat_{short_tl1.20,foreground_burst_tl0.90,inflight_burst_tl0.70}_seed42.json`
Regenerate with:
```
.venv/bin/python benchmarks/diffusion/generate_runtime_v2_mixed_priority_workload.py \
  --adapter qwen --cost-model-dir cost-model/qwen-image --num-gpus 4 \
  --profile <short|foreground_burst|inflight_burst> --target-load <1.20|0.90|0.70> \
  --seed 42 --out workloads/<name>.json
```

## Run the full 8-policy battery for one profile
```
export LD_LIBRARY_PATH="" HF_HUB_OFFLINE=1
MODEL=Qwen/Qwen-Image TASK=t2i BENCH_BACKEND=openai SERVE_EXTRA_ARGS="" \
  COST_MODEL_DIR=cost-model/qwen-image GPUS=4,5,6,7 NUM_GPUS=4 SP_SIZES=1,2,4 \
  POLICIES="edf_greedy edf_best_fit srtf_sp1 srtf_sp2 srtf_sp4 fcfs_sp1 fcfs_sp2 fcfs_sp4" \
  WORKLOADS="out/stress/qwenbat_short_tl1.20_seed42.json" \
  OUT_ROOT=out/qwen_battery_planB VENV_BIN=/home/LOCAL/shixuan/xinwei/.venv/bin \
  SERVER_GREP=Qwen-Image PORT=8098 BENCH_TIMEOUT=3600 \
  bash scripts/run_h20_battery.sh
```
Detached (survives ssh drop):
```
setsid nohup bash scripts/run_h20_battery.sh > driver.log 2>&1 < /dev/null & disown
```

## Policy topology semantics (sweep_policies.sh)
- `edf_greedy` / `edf_best_fit`: elastic SP{1,2,4} lanes, cost-model-driven SP selection.
- `srtf_spN` / `fcfs_spN`: static topology — sp1 = 4 independent SP1 lanes (max concurrency);
  sp2 = 2 SP2 lanes; sp4 = one SP4 group (max per-request parallelism).

## Results layout
`results/<profile>/sweep_<policy>_{result.json,bench.log,server.log}`
SLO numbers in `SUMMARY.md` are recomputed from the per-class fields of each result.json.
