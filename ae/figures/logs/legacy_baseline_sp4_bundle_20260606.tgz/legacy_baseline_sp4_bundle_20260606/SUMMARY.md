# Legacy Baseline (pre-adaptive-serving, commit cf328eb)

Static SP=4 (ulysses=4, one group), FIFO, no runtime_v2 / no elastic lanes. 4x H20.
Server = cf328eb via PYTHONPATH worktree; bench = current-HEAD mixed_priority client (HTTP-only). See COMMIT.txt.
Wan runs use --guidance-scale 4.0 (true CFG) to match the runtime_v2 wan adapter's
default_guidance_scale=4.0; Qwen runs omit it (do_true_cfg=False both sides).

| run | done | SLO_all | S | M | L | p99 (s) | mean (s) | qps |
|---|---|---|---|---|---|---|---|---|
| Qwen short (tl1.20) | 127/127 | 13.4% | 3% | 19% | 64% | 687.2 | 322.7 | 0.102 |
| Qwen fg_burst (tl0.90) | 257/257 | 6.6% | 0% | 13% | 20% | 1308.6 | 740.0 | 0.089 |
| Qwen inflight (tl0.70) | 108/108 | 22.2% | 2% | - | 100% | 405.1 | 191.6 | 0.091 |
| Wan short (tl1.20) | 61/61 | 31.1% | 18% | 50% | 100% | 900.0 | 399.2 | 0.031 |
| Wan fg_burst (tl1.10) | 65/65 | 21.5% | 0% | 31% | 71% | 1376.5 | 680.5 | 0.023 |
| Wan inflight (tl0.90) | 23/23 | 60.9% | 47% | - | 100% | 347.3 | 163.7 | 0.023 |

## Context: legacy SP4 vs new-runtime static SP4 vs best elastic (Qwen)

| profile | legacy SP4 | planB fcfs_sp4 | planB best |
|---|---|---|---|
| Qwen short | 13.4% | 12.6% | 83.5% edf_best_fit |
| Qwen fg_burst | 6.6% | 6.2% | 73.5% edf_greedy |
| Qwen inflight | 22.2% | 21.3% | 82.4% srtf_sp1 |

Legacy SP4 matches new-runtime static fcfs_sp4 across all three Qwen profiles
(13.4~=12.6, 6.6~=6.2, 22.2~=21.3): the runtime itself did not get faster; the
EDF/elastic gains are pure scheduling.

## Wan: CFG alignment (why the first attempt was invalid)

First Wan legacy attempt ran guidance=0.0 (no CFG) because the bench never sends
guidance and legacy's default is 0.0, while the runtime_v2 wan adapter falls back
to default_guidance_scale=4.0 (CFG on, 2 forward passes/step). That made legacy do
HALF the compute -> falsely better (Wan short 36.1% vs new-runtime fcfs_sp4 27.9%).
After injecting --guidance-scale 4.0, legacy does true CFG and aligns:
Wan short legacy 31.1% vs new-runtime fcfs_sp4 27.9% (3.2pp, same as the Qwen story).
Throughput likewise aligns: clean Wan-short legacy qps 0.031 ~= new-runtime fcfs_sp4 0.031
(ratio ~0.99) -- the runtime did not get faster.

## 2026-06-06 repackage: Wan-short replaced with a contention-free re-run

The original Wan-short in the 2026-05-29 bundle was run on a shared box overnight and
was uniformly ~1.5x slower per class (S 1.56x / M 1.44x / L 1.46x; makespan 2523s vs
1964s, +28%) -- a contention signature, not a real result. It was re-run clean on
2026-05-30 (`driver_wan_short_rerun.log`, identical args + guidance=4.0); this bundle
now carries that clean run (mean 610.9->399.2s, p99 1459->900s, qps 0.024->0.031, L
67%->100%, SLO_all 29.5%->31.1%).

CAVEAT: Wan fg_burst / inflight were part of the SAME 2026-05-29 overnight batch and
were NOT re-run, so their absolute latency/throughput may carry residual contention
(treat as upper-bound makespan / lower-bound qps). SLO is far less sensitive. Re-run
both clean (no concurrent GPU jobs) before quoting their absolute throughput. The
`fcfs_sp4/legacy` throughput ratio is ~0.99 on the clean Wan-short and ~1.02 on the
(un-rerun) fg -- both ~1.0, consistent with "runtime did not get faster".
(The working-dir `COMPARISON.md`, not included here, still shows the invalid no-CFG
Wan numbers 36.1/38.5/65.2% -- superseded by this SUMMARY.)
