import json, os
base = "/home/LOCAL/shixuan/xinwei/vllm-omni-private/out/legacy_baseline_sp4"
runs = [("qwen_short","Qwen short"),("qwen_fg","Qwen fg_burst"),("qwen_inflight","Qwen inflight"),
        ("wan_short","Wan short"),("wan_fg","Wan fg_burst"),("wan_inflight","Wan inflight")]
hdr = f'{"run":<16}{"done":>9}{"SLO_all":>9}{"S":>6}{"M":>6}{"L":>6}{"p99":>8}{"mean":>8}{"qps":>7}'
print(hdr)
for tag, label in runs:
    p = os.path.join(base, tag, "legacy_sp4_result.json")
    if not os.path.exists(p):
        print(f"{label:<16}  MISSING"); continue
    r = json.load(open(p)); pc = r["per_class"]
    met = sum(pc[c]["slo_met"] for c in pc); dfn = sum(pc[c]["slo_defined"] for c in pc)
    def cl(c): return f'{pc[c]["slo_attainment_rate"]*100:.0f}%' if c in pc else "-"
    done = f'{r["completed_requests"]}/{r["completed_requests"]+r["failed_requests"]}'
    print(f'{label:<16}{done:>9}{met/dfn*100:>8.1f}%{cl("S"):>6}{cl("M"):>6}{cl("L"):>6}{r["latency_p99"]:>8.1f}{r["latency_mean"]:>8.1f}{r["throughput_qps"]:>7.3f}')
