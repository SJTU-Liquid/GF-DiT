#!/bin/bash
# Legacy (pre-adaptive-serving) baseline on h20.
# Server: cf328eb code via PYTHONPATH=legacy worktree, static SP=4, FIFO, no runtime_v2.
# Bench:  current-HEAD mixed_priority client from the main repo (HTTP-only, server-agnostic).
#
# One run per (model, workload). Server uses GPUs 3,4,5,6 at ulysses=4 (one SP4 group).
#
# Detached launch:
#   setsid nohup bash /tmp/run_legacy_baseline.sh > <main>/out/qwen_battery_legacy/driver.log 2>&1 < /dev/null & disown
set -uo pipefail

MAIN=/home/LOCAL/shixuan/xinwei/vllm-omni-private
LEGACY=/home/LOCAL/shixuan/xinwei/vllm-omni-legacy
VENV=/home/LOCAL/shixuan/xinwei/.venv/bin
GPUS="${GPUS:-3,4,5,6}"
NUM_GPUS=4
PORT="${PORT:-8098}"
OUT_ROOT="${OUT_ROOT:-$MAIN/out/qwen_battery_legacy}"
BENCH_TIMEOUT="${BENCH_TIMEOUT:-3600}"
# Allow restricting which runs via RUNS env (space-separated tags); default all 6.
RUNS="${RUNS:-qwen_short qwen_fg qwen_inflight wan_short wan_fg wan_inflight}"

export LD_LIBRARY_PATH=""
export HF_HUB_OFFLINE=1

mkdir -p "$OUT_ROOT"

# tag -> "model|task|backend|serve_extra|workload|grep"
run_spec() {
  case "$1" in
    qwen_short)    echo "Qwen/Qwen-Image|t2i|openai||out/stress/qwenbat_short_tl1.20_seed42.json|Qwen-Image";;
    qwen_fg)       echo "Qwen/Qwen-Image|t2i|openai||out/stress/qwenbat_foreground_burst_tl0.90_seed42.json|Qwen-Image";;
    qwen_inflight) echo "Qwen/Qwen-Image|t2i|openai||out/stress/qwenbat_inflight_burst_tl0.70_seed42.json|Qwen-Image";;
    wan_short)     echo "Wan-AI/Wan2.2-TI2V-5B-Diffusers|t2v|v1/videos|--boundary-ratio 0.875 --flow-shift 5.0|out/stress/h20bat_short_tl1.20_a2.0_2.5_3.5_seed42.json|Wan2.2";;
    wan_fg)        echo "Wan-AI/Wan2.2-TI2V-5B-Diffusers|t2v|v1/videos|--boundary-ratio 0.875 --flow-shift 5.0|out/stress/h20bat_foreground_burst_tl1.10_a2.0_2.5_3.5_seed42.json|Wan2.2";;
    wan_inflight)  echo "Wan-AI/Wan2.2-TI2V-5B-Diffusers|t2v|v1/videos|--boundary-ratio 0.875 --flow-shift 5.0|out/stress/h20bat_inflight_burst_tl0.90_a2.0_2.5_3.5_seed42.json|Wan2.2";;
    *) echo "";;
  esac
}

echo "=== [$(date '+%F %T')] LEGACY baseline START (commit $(cd $LEGACY && git rev-parse --short HEAD)) ==="
echo "  gpus=$GPUS sp=4(ulysses) port=$PORT out=$OUT_ROOT"
echo "  runs: $RUNS"

for tag in $RUNS; do
  spec=$(run_spec "$tag")
  if [ -z "$spec" ]; then echo "SKIP unknown tag $tag"; continue; fi
  IFS='|' read -r MODEL TASK BACKEND SERVE_EXTRA WL GREP <<< "$spec"
  if [ ! -f "$MAIN/$WL" ]; then echo "=== SKIP (missing workload): $WL ==="; continue; fi

  od="$OUT_ROOT/$tag"; mkdir -p "$od"
  slog="$od/legacy_sp4_server.log"; blog="$od/legacy_sp4_bench.log"; res="$od/legacy_sp4_result.json"
  rm -f "$slog" "$blog" "$res"
  echo "=== [$(date '+%m-%d %H:%M:%S')] RUN $tag : $MODEL ($TASK/$BACKEND) wl=$(basename $WL) ==="

  # --- legacy server (PYTHONPATH=legacy worktree) ---
  CUDA_VISIBLE_DEVICES="$GPUS" PYTHONPATH="$LEGACY" nohup "$VENV/vllm" serve "$MODEL" --omni \
    --port "$PORT" --num-gpus "$NUM_GPUS" --ulysses-degree "$NUM_GPUS" \
    $SERVE_EXTRA --enforce-eager \
    > "$slog" 2>&1 &
  SPID=$!
  READY=no
  for i in $(seq 1 180); do
    code=$(curl -s -o /dev/null -w '%{http_code}' "http://localhost:$PORT/health" 2>/dev/null)
    if [ "$code" = "200" ]; then READY=yes; break; fi
    if ! kill -0 "$SPID" 2>/dev/null; then break; fi
    sleep 4
  done

  # Align CFG: Wan (v1/videos) needs guidance_scale=4.0 so the legacy server
  # does true CFG, matching the runtime_v2 wan adapter's default_guidance_scale=4.0.
  # Qwen image workloads are do_true_cfg=False, so no guidance injection there.
  GUIDANCE_ARG=""
  [ "$BACKEND" = "v1/videos" ] && GUIDANCE_ARG="--guidance-scale 4.0"

  if [ "$READY" = "yes" ]; then
    echo "  [$(date '+%H:%M:%S')] $tag healthy -> benchmark ${GUIDANCE_ARG}"
    cd "$MAIN"
    timeout "$BENCH_TIMEOUT" "$VENV/python" benchmarks/diffusion/diffusion_benchmark_serving.py \
      --backend "$BACKEND" --task "$TASK" --model "$MODEL" --dataset mixed_priority \
      --workload-json "$WL" --num-prompts 100000 --max-concurrency 256 --port "$PORT" \
      $GUIDANCE_ARG --output-file "$res" > "$blog" 2>&1
    echo "  [$(date '+%H:%M:%S')] $tag benchmark exit=$?"
  else
    echo "  [$(date '+%H:%M:%S')] $tag SKIPPED -- server unhealthy"
    grep -iE "error|traceback|importerror|no such|unrecognized|invalid" "$slog" 2>/dev/null | grep -viE "futurewarning|deprecat" | head -8
  fi

  pkill -f "vllm serve $MODEL --omni --port $PORT" 2>/dev/null
  sleep 6
  ps -eo pid,cmd | grep -E "$GREP|EngineCore|multiprocessing.spawn" | grep -v grep | awk '{print $1}' | xargs -r kill -9 2>/dev/null
  sleep 10
  echo "  [$(date '+%H:%M:%S')] $tag done, server down"
done
echo "=== [$(date '+%F %T')] LEGACY baseline COMPLETE ==="
