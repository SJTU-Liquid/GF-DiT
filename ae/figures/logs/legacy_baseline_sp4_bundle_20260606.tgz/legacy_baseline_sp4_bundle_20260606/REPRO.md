# Reproduction -- legacy baseline

## Two checkouts (see COMMIT.txt)
- SERVER: a git worktree at the legacy commit (runtime_v2's parent):
  `git worktree add ../vllm-omni-legacy <SERVER_COMMIT>`
- BENCH: the main repo at current HEAD (mixed_priority client + workloads).

## Run (per (model, workload)): legacy server + current bench
```
export LD_LIBRARY_PATH="" HF_HUB_OFFLINE=1
# legacy server: PYTHONPATH forces import of the worktree's vllm_omni
CUDA_VISIBLE_DEVICES=3,4,5,6 PYTHONPATH=/path/to/vllm-omni-legacy \
  .venv/bin/vllm serve <MODEL> --omni --port 8098 \
  --num-gpus 4 --ulysses-degree 4 [--boundary-ratio 0.875 --flow-shift 5.0 for Wan] \
  --enforce-eager &
# wait /health == 200, then current-HEAD bench (server-agnostic HTTP client):
.venv/bin/python benchmarks/diffusion/diffusion_benchmark_serving.py \
  --backend <openai|v1/videos> --task <t2i|t2v> --model <MODEL> \
  --dataset mixed_priority --workload-json out/stress/<workload>.json \
  --num-prompts 100000 --max-concurrency 256 --port 8098 \
  --output-file <out>/legacy_sp4_result.json
```
Full 6-run driver: `scripts/run_legacy_baseline.sh` (RUNS env selects a subset).

## Verifying it really runs legacy code
```
PYTHONPATH=/path/to/vllm-omni-legacy .venv/bin/python -c \
  "import vllm_omni; print(vllm_omni.__file__); import vllm_omni.diffusion.runtime_v2"
# -> worktree path, then ModuleNotFoundError for runtime_v2 (absent at cf328eb).
```

## Models / workloads
- Qwen: Qwen/Qwen-Image, t2i, backend openai
- Wan:  Wan-AI/Wan2.2-TI2V-5B-Diffusers, t2v, backend v1/videos
SLO is computed client-side from each workload's per-request deadline (server-agnostic).
