# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

from collections import deque

from vllm_omni.diffusion.runtime_v2.policies.srtf import SRTFSchedulerPolicy
from vllm_omni.diffusion.runtime_v2.protocol import InferenceTask
from vllm_omni.diffusion.runtime_v2.topology import RuntimeTopology

from vllm_omni.diffusion.runtime_v2.policies.common import TaskRuntimeEstimator


class SJFSchedulerPolicy(SRTFSchedulerPolicy):
    """Non-preemptive Shortest-Job-First.

    Reuses SRTF's request/group binding and runtime accounting but changes the
    two properties that make SRTF "SRTF":

    * **Orders by total job size, not remaining work.** A request is ranked by
      the estimated runtime of its *whole* plan, fixed at submission, so its
      priority never shifts as it makes progress. (Among requests that have not
      started yet this equals their remaining work, which is why the value is
      snapshotted lazily the first time a request is considered.)
    * **Non-preemptive.** Once a group starts serving a request it stays pinned
      to that request until it finishes. A shorter request that arrives mid-flight
      waits, rather than displacing the running one at the next task boundary
      (which is exactly what SRTF would do).
    """

    def __init__(
        self,
        topology: RuntimeTopology,
        task_runtime_estimator: TaskRuntimeEstimator | None = None,
    ) -> None:
        super().__init__(topology, task_runtime_estimator)
        # request_id -> total estimated work. Snapshotted from remaining work the
        # first time a request is up for selection, when no task of it has been
        # charged yet so remaining work still equals the total job size.
        self.request_total_work: dict[str, float] = {}

    def _select_shortest_request(
        self,
        group_id: str,
        by_request: dict[str, deque[InferenceTask]],
    ) -> str | None:
        if not by_request:
            return None
        active_request = self.active_request_by_group.get(group_id)
        if active_request is not None:
            # In-flight request holds the group (non-preemptive). active_request_by_group
            # only carries a value between a request's first dispatch and its
            # REQUEST_FINISHED, so a non-None entry means that request is still
            # running here. If its next task is not runnable yet, leave the group
            # idle rather than admitting a different request.
            return active_request if active_request in by_request else None
        # Group is free: admit the waiting request with the smallest total job.
        for request_id in by_request:
            if request_id not in self.request_total_work:
                self.request_total_work[request_id] = self.request_remaining_work.get(
                    request_id, float("inf")
                )
        return min(
            by_request.keys(),
            key=lambda request_id: (
                self.request_total_work.get(request_id, float("inf")),
                request_id,
            ),
        )

    def _cleanup_request_work(self, request_id: str, group_id: str | None = None) -> None:
        self.request_total_work.pop(request_id, None)
        super()._cleanup_request_work(request_id=request_id, group_id=group_id)
