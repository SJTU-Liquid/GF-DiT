# Objective-dependent policy (simulator, H20 4-card config)

EDF excluded; non-preemptive SJF added. FCFS-SP4 == the "Legacy" static-SP4-FIFO baseline. No migration in any run (static SP) so sim tracks real H20 for this policy set.

## Figure data: winner per (workload x per-class objective)

| Workload | 前台SLO(S) | 前台延迟(S median) | 中台延迟(M median) | 后台延迟(L median) | 整体尾(overall P99) |
|---|---|---|---|---|---|
| WAN short | **SRTF-SP1** 72% | **SRTF-SP4** 59s | **SRTF-SP1** 136s | **FCFS-SP1** 300s | **FCFS-SP1** 355s |
| WAN FG burst | **SRTF-SP1** 68% | **SRTF-SP4** 81s | **SRTF-SP1** 97s | **FCFS-SP1** 288s | **FCFS-SP1** 635s |
| QWEN short | **SRTF-SP1** 73% | **SRTF-SP1** 9s | **SJF-SP1** 52s | **FCFS-SP1** 114s | **FCFS-SP1** 240s |
| QWEN FG burst | **SRTF-SP1** 53% | **SRTF-SP1** 11s | **SRTF-SP1** 39s | **FCFS-SP1** 277s | **FCFS-SP1** 367s |

## Reference: winner per (workload x overall objective)

| Workload | SLO | Mean | Median | P95 | P99 | Throughput |
|---|---|---|---|---|---|---|
| WAN short | **SRTF-SP1** 73.8% | **SRTF-SP1** 147s | **SRTF-SP1** 102s | **FCFS-SP1** 300s | **FCFS-SP1** 355s | **SRTF-SP1** 2.52/min |
| WAN FG burst | **SRTF-SP1** 80.0% | **SRTF-SP1** 213s | **SRTF-SP1** 109s | **SJF-SP1** 579s | **FCFS-SP1** 635s | **FCFS-SP1** 1.91/min |
| QWEN short | **SRTF-SP1** 67.7% | **SRTF-SP1** 51s | **SRTF-SP1** 15s | **FCFS-SP1** 199s | **FCFS-SP1** 240s | **SRTF-SP1** 9.52/min |
| QWEN FG burst | **SRTF-SP1** 58.4% | **SRTF-SP1** 98s | **SRTF-SP1** 26s | **FCFS-SP1** 348s | **FCFS-SP1** 367s | **FCFS-SP1** 8.33/min |

## 指标菜单: 每个 scope×metric 候选目标的获胜者 (Δ=6 policy 间极差, 越大越能区分)

| 目标(scope·metric) | WAN short | WAN FG burst | QWEN short | QWEN FG burst |
|---|---|---|---|---|
| S(前台) SLO | SRTF-SP1 72% (Δ55%) | SRTF-SP1 68% (Δ68%) | SRTF-SP1 73% (Δ70%) | SRTF-SP1 53% (Δ53%) |
| S(前台) mean | SRTF-SP4 79s (Δ317s) | SRTF-SP4 98s (Δ544s) | SRTF-SP1 10s (Δ380s) | SRTF-SP1 15s (Δ859s) |
| S(前台) median | SRTF-SP4 59s (Δ383s) | SRTF-SP4 81s (Δ606s) | SRTF-SP1 9s (Δ417s) | SRTF-SP1 11s (Δ971s) |
| S(前台) p95 | SRTF-SP4 168s (Δ637s) | SRTF-SP4 208s (Δ1024s) | SRTF-SP1 17s (Δ747s) | SRTF-SP1 34s (Δ1480s) |
| S(前台) p99 | SRTF-SP4 200s (Δ637s) | SRTF-SP4 226s (Δ1054s) | SRTF-SP1 18s (Δ778s) | SRTF-SP1 43s (Δ1499s) |
| M(中台) SLO | FCFS-SP1 83% (Δ56%) | SRTF-SP1 92% (Δ62%) | SJF-SP1 62% (Δ48%) | SRTF-SP1 64% (Δ51%) |
| M(中台) mean | FCFS-SP1 160s (Δ417s) | SRTF-SP1 146s (Δ465s) | SRTF-SP1 70s (Δ419s) | SRTF-SP1 60s (Δ825s) |
| M(中台) median | SRTF-SP1 136s (Δ627s) | SRTF-SP1 97s (Δ353s) | SJF-SP1 52s (Δ522s) | SRTF-SP1 39s (Δ837s) |
| M(中台) p95 | FCFS-SP1 291s (Δ626s) | SRTF-SP1 278s (Δ1034s) | SRTF-SP1 134s (Δ639s) | SRTF-SP1 139s (Δ1400s) |
| M(中台) p99 | FCFS-SP1 292s (Δ641s) | SRTF-SP1 331s (Δ991s) | SRTF-SP1 139s (Δ654s) | SJF-SP1 204s (Δ1346s) |
| L(后台) SLO | FCFS-SP1 100% (Δ67%) | FCFS-SP1 100% (Δ86%) | FCFS-SP1 100% (Δ100%) | FCFS-SP1 100% (Δ94%) |
| L(后台) mean | SJF-SP1 331s (Δ794s) | FCFS-SP1 354s (Δ814s) | FCFS-SP1 153s (Δ756s) | FCFS-SP1 254s (Δ1439s) |
| L(后台) median | FCFS-SP1 300s (Δ815s) | FCFS-SP1 288s (Δ943s) | FCFS-SP1 114s (Δ821s) | FCFS-SP1 277s (Δ1550s) |
| L(后台) p95 | SJF-SP1 412s (Δ938s) | FCFS-SP1 554s (Δ879s) | FCFS-SP1 257s (Δ726s) | FCFS-SP1 361s (Δ1526s) |
| L(后台) p99 | SJF-SP1 422s (Δ949s) | FCFS-SP1 566s (Δ887s) | FCFS-SP1 264s (Δ745s) | FCFS-SP1 397s (Δ1511s) |
| 全局overall SLO | SRTF-SP1 74% (Δ39%) | SRTF-SP1 80% (Δ58%) | SRTF-SP1 68% (Δ58%) | SRTF-SP1 58% (Δ53%) |
| 全局overall mean | SRTF-SP1 147s (Δ217s) | SRTF-SP1 213s (Δ427s) | SRTF-SP1 51s (Δ319s) | SRTF-SP1 98s (Δ781s) |
| 全局overall median | SRTF-SP1 102s (Δ255s) | SRTF-SP1 109s (Δ569s) | SRTF-SP1 15s (Δ362s) | SRTF-SP1 26s (Δ876s) |
| 全局overall p95 | FCFS-SP1 300s (Δ587s) | SJF-SP1 579s (Δ748s) | FCFS-SP1 199s (Δ705s) | FCFS-SP1 348s (Δ1515s) |
| 全局overall p99 | FCFS-SP1 355s (Δ865s) | FCFS-SP1 635s (Δ800s) | FCFS-SP1 240s (Δ712s) | FCFS-SP1 367s (Δ1521s) |

## All policies (per workload)

### WAN short

| Policy | SLO | Mean | Median | P95 | P99 | Throughput | n(comp/total) |
|---|---|---|---|---|---|---|---|
| FCFS-SP1 | 55.7% | 165s | 162s | 300s | 355s | 2.52/min | 61/61 |
| SRTF-SP1 | 73.8% | 147s | 102s | 408s | 546s | 2.52/min | 61/61 |
| SJF-SP1 | 55.7% | 157s | 122s | 403s | 461s | 2.52/min | 61/61 |
| FCFS-SP4 | 34.4% | 364s | 357s | 787s | 832s | 1.91/min | 61/61 |
| SRTF-SP4 | 54.1% | 252s | 113s | 874s | 1220s | 1.91/min | 61/61 |
| SJF-SP4 | 47.5% | 270s | 130s | 887s | 1008s | 1.91/min | 61/61 |

### WAN FG burst

| Policy | SLO | Mean | Median | P95 | P99 | Throughput | n(comp/total) |
|---|---|---|---|---|---|---|---|
| FCFS-SP1 | 49.2% | 276s | 268s | 589s | 635s | 1.91/min | 65/65 |
| SRTF-SP1 | 80.0% | 213s | 109s | 716s | 840s | 1.91/min | 65/65 |
| SJF-SP1 | 49.2% | 256s | 226s | 579s | 737s | 1.91/min | 65/65 |
| FCFS-SP4 | 21.5% | 640s | 678s | 1263s | 1311s | 1.41/min | 65/65 |
| SRTF-SP4 | 49.2% | 356s | 132s | 1327s | 1434s | 1.41/min | 65/65 |
| SJF-SP4 | 46.2% | 362s | 145s | 1327s | 1434s | 1.41/min | 65/65 |

### QWEN short

| Policy | SLO | Mean | Median | P95 | P99 | Throughput | n(comp/total) |
|---|---|---|---|---|---|---|---|
| FCFS-SP1 | 28.3% | 99s | 110s | 199s | 240s | 9.52/min | 127/127 |
| SRTF-SP1 | 67.7% | 51s | 15s | 252s | 384s | 9.52/min | 127/127 |
| SJF-SP1 | 37.8% | 62s | 33s | 252s | 345s | 9.52/min | 127/127 |
| FCFS-SP4 | 12.6% | 370s | 377s | 774s | 802s | 5.60/min | 127/127 |
| SRTF-SP4 | 12.6% | 281s | 137s | 904s | 952s | 5.60/min | 127/127 |
| SJF-SP4 | 9.4% | 282s | 147s | 904s | 952s | 5.60/min | 127/127 |

### QWEN FG burst

| Policy | SLO | Mean | Median | P95 | P99 | Throughput | n(comp/total) |
|---|---|---|---|---|---|---|---|
| FCFS-SP1 | 23.3% | 211s | 235s | 348s | 367s | 8.33/min | 257/257 |
| SRTF-SP1 | 58.4% | 98s | 26s | 488s | 604s | 8.33/min | 257/257 |
| SJF-SP1 | 24.5% | 115s | 58s | 457s | 549s | 8.33/min | 257/257 |
| FCFS-SP4 | 6.2% | 879s | 901s | 1522s | 1551s | 4.86/min | 257/257 |
| SRTF-SP4 | 6.6% | 595s | 256s | 1863s | 1888s | 4.86/min | 257/257 |
| SJF-SP4 | 5.4% | 596s | 260s | 1863s | 1888s | 4.86/min | 257/257 |
