# Objective-dependent policy — simulator bundle

Self-contained bundle to reproduce / re-plot the **objective-dependent policy**
figure via the runtime_v2 policy **simulator** (not real HW), on the measured
**H20 4-card** config.

Difference vs the original figure: **EDF (the adaptive policy) is removed**, and a
**non-preemptive SJF** is added. Policies compared: `{FCFS, SRTF, SJF} × {SP1, SP4}`
(FCFS-SP4 == the old "Legacy" static-SP4-FIFO baseline).

Why the simulator is faithful here: every policy in this set is static-SP, so there
is **no cross-group migration / reshard** in any run — and the known sim↔real gap is
driven entirely by EDF's migration orchestration. With EDF gone, the sim tracks real
H20 closely for exactly this policy set.

## Layout

```
data/                 # the results (what you plot)
  figure_winners.csv  # per-class objective framing: winner per (workload × objective)
  all_metrics_long.csv# EVERY scope (S/M/L/overall) × metric (SLO/mean/median/p95/p99)
                      #   per policy — use this to pick which columns the figure shows
  metrics_long.csv    # overall (all-request) metrics, 1 row per (workload × policy)
  grid_results.json   # full structured dump incl. per-class S/M/L, makespan, throughput
  winners.md          # rendered tables: per-class table + overall table + metric menu
code/
  objective_policy_grid_sim.py  # the driver (runs the grid, writes data/)
  sjf.py                        # SJFSchedulerPolicy (non-preemptive shortest-job-first)
  test_runtime_v2_scheduler_policy.py  # unit tests incl. the 2 new SJF tests
workloads/            # the measured H20 4-card workloads (seed 42), num_gpus=4
  h20bat_short_tl1.20_*.json              # WAN short            (61 reqs, 1200s)
  h20bat_foreground_burst_tl1.10_*.json   # WAN foreground burst (65 reqs, 1800s)
  qwenbat_short_tl1.20_seed42.json        # QWEN short           (127 reqs, 600s)
  qwenbat_foreground_burst_tl0.90_seed42.json  # QWEN foreground burst (257 reqs, 1800s)
cost-model/           # H20-native cost models (per-stage a·x²+b·x+c, by SP width)
  wan22-ti2v-5b-h20/  # WAN
  qwen-image/         # QWEN
```

## Config

- world_size = 4. SP1 = four 1-rank lanes; SP4 = one 4-rank group (tp=1).
- Workloads are the canonical battery loads: WAN short tl1.20 / fg_burst tl1.10;
  QWEN short tl1.20 / fg_burst **tl0.90** (the load the real QWEN experiment replayed).
- SJF = non-preemptive shortest-**total**-job-first (ranks by whole-plan estimated
  work, fixed at submit; pins a group to its running request until it finishes).

## Reproduce

From the repo root (needs the project .venv with vllm):

```bash
PYTHONPATH=. .venv/bin/python benchmarks/diffusion/objective_policy_grid_sim.py \
    --out-dir out/objective_sim --include-qwen
```

Unit tests for the SJF policy:

```bash
.venv/bin/python -m pytest tests/diffusion/test_runtime_v2_scheduler_policy.py -k sjf -q
```

## Key finding / framing

Under **overall** (all-request) metrics only 2 policies win anything: SRTF-SP1 takes
all central objectives (SLO/mean/median), FCFS-SP1 takes the tail (P95/P99). SJF is a
"middle" policy (between SRTF's aggressive short-first and FCFS's no-starvation) so it
almost never strictly wins overall.

The real differentiation lives at the **per-class** level — so the figure uses per-class
objectives, where 4 policies appear:
- **SRTF-SP1** — foreground (S) SLO, overall central latency, most M
- **SRTF-SP4** — single-foreground-job latency on WAN (wide SP finishes one job faster)
- **SJF-SP1** — niches: QWEN-short M, a few tail cells
- **FCFS-SP1** — background (L) latency, overall tail (no starvation / no reordering)

Note: **L-SLO is ~100% for several policies** (loose L deadlines) → not differentiating;
use L median/p95 to represent "background", not L-SLO. **Throughput** only depends on
SP1-vs-SP4 (identical across FCFS/SRTF/SJF) so it's dropped from the figure.
