# A100 8-GPU Diffusion Serving Benchmark — Summary

**Hardware:** vast.ai 8×A100-SXM4-80GB (NV12 full NVLink). GEMM 247 bf16 TFLOP/s, HBM 1.76 TB/s — healthy full-spec A100.
**Stack:** vllm 0.17.0 + vllm_omni runtime_v2 (elastic SP), torch 2.10.0+cu130, GFC collective backend, `--enforce-eager`.
**Models:** Qwen-Image (20B DiT, image, nocfg) and Wan2.2-TI2V-5B (video).
**Policies:** `edf_best_fit` / `edf_greedy` (elastic EDF) vs static baselines `srtf_sp1` (SRTF, N SP1 lanes), `srtf_sp8` (SRTF, single SP8 group), `fcfs_sp1`, `legacy` (cf328eb, no runtime_v2, SP8 FIFO).
**Metric:** per-class SLO attainment (S/M/L), deadline = arrival + alpha·T_single.

Cost models re-profiled & validated on this box (per-step exec matches cost model: M/L ratio ~1.0, S +11% small-image fixed head).

---

## WAN 2.2-TI2V-5B (alpha S2.0/M2.5/L3.5, +5000ms client tax)

| policy | short (tl1.05) | fg (tl0.9) |
|---|---|---|
| **edf_best** | **90.7** | **88.8** |
| srtf_sp1 | 47.0 | 79.5 |
| srtf_sp8 | 31.8 | 21.7 |
| fcfs_sp1 | 20.5 | 59.6 |
| legacy SP8 FIFO | 11.3 | 7.5 |

(+ inflight tl0.6 edf_best 94.6). **edf_best wins decisively; real ≈ sim (short −6pp, fg −1.9pp)** — wan tracks sim well.

---

## QWEN-Image (alpha S1.5/M2.0/L6.0 "origalpha", +1000ms client tax) — MAIN

| policy | short (tl1.0) [S/M/L] | fg (tl0.7) [S/M/L] |
|---|---|---|
| **edf_best** | **75.3** [78/72/69] | **74.2** [68/82/87] |
| edf_greedy | 72.8 [76/67/69] | 73.2 [66/83/88] |
| srtf_sp1 | 62.7 [65/48/96] | 60.8 [48/68/97] |
| fcfs_sp1 | 29.7 [13/46/100] | 37.3 [15/48/100] |
| srtf_sp8 | 0.0 [0/0/0] | 1.9 [0/11/0] |
| legacy SP8 FIFO | 3.2 [1/4/19] | 3.7 [0/7/13] |

**edf_best wins both (+12.6 / +13.4 over srtf_sp1); edf_greedy ≈ edf_best.** Structure matches h20.
Static single-SP8-group (srtf_sp8, legacy) is catastrophic for qwen: one request at a time on 8 GPUs + small-latent collective floor → ~0-4%, many client timeouts.

---

## KEY FINDINGS

### 1. sim/real gap (~25pp for qwen) = per-step dispatch/IPC idle, NOT migration
Decomposed on qwen short tl1.0 origalpha edf_best (sim 100% → real 75.3%, matched per-request, n=316):
- **Per-step GPU exec matches the cost model** (M/L ratio 1.00-1.02; S +11% small-image fixed head). Compute is NOT under-predicted.
- **Throughput:** offered 0.527 / **sim 0.517** (makespan 611s, idle 0.4%) / **real 0.465** (makespan 679s, GPU dit-util 88.2% ≈ 10% idle).
- **The ~10% real GPU idle = inter-step scheduler↔worker round-trip + Hop1 IPC handoff** (~15ms/step). The sim prices this at zero (back-to-back) and also prices reshard/migration at 0ms (358 switches, 0 cost).
- **Migration ruled out:** `srtf_sp1` (zero migrations) has the SAME ~11% idle (util 89.2%) and the same throughput shortfall. So the gap is the serving-pipeline per-step gap, common to all policies — not elastic migration, not per-step compute, not "extra dispatch" (dispatch is already in the cost model).
- Near capacity this ~12% throughput shortfall flips real from "just keeps up (sim 100%)" to "slightly overloaded (real 75%)" → queue grows → tail (L) latency balloons → SLO drops. **Fix direction (unverified): cut the per-step dispatch gap (multi-step chunk dispatch / fewer Hop1 round-trips).**

### 2. SLO-scale (alpha) sensitivity — explains an apparent "edf loses" detour
With **wan-scale alpha (S2.0/M2.5/L3.5, L tightened from 6.0→3.5)**: qwen short srtf_sp1 (79.1) > edf_best (59.8). With **origalpha (L=6.0)**: edf_best (75.3) > srtf_sp1 (62.7).
Cause: **srtf_sp1's L is always strong (96/97), edf's L always weaker (69/87→50 when tight)** — edf does NOT proactively widen the deadline-pressured L (best_fit picks smallest SP that fits its queue-blind estimate), and elastic lane-churn defers L. Loose L hides this (edf wins on S/M); tight L exposes it (edf loses). Not a hardware/code anomaly — purely the alpha regime.

### 3. GFC collective (microbench, see gfc_a100_collective_bench)
all2all 16Ki: eager 167us / eager+sleep 166us / **cudagraph 25us**. GFC eager floor ~165us = **synchronous host work** (symm-mem signaling), not async launch (sleep can't hide it), removed by cudagraph. Pure-GPU kernels competitive with NCCL. Serving uses eager (elastic SP precludes cudagraph) → pays this host sync per collective.

---

## DATA LAYOUT (in this bundle)
- `wan_a100_bundle/` — wan 5-policy × short/fg (+ inflight edf_best) result.json + server/bench logs + cost model.
- `qwen_a100_bundle/` — session-1 recovered: qwen short tl1.1 edf_best 65.5; light tl1.0 edf_best 77.8 / greedy 78.2 / srtf_sp1 63.3.
- `a100_session2/out/battery8a100_qwen_origalpha/` — **qwen origalpha 6-policy × short/fg (MAIN), incl 24 server logs** (dispatch-gap raw material).
- `a100_session2/out/battery8a100_qwen_wanscale/` — exploratory wan-scale-alpha (short edf_best 59.8/greedy 54.1/srtf_sp1 79.1; fg edf_best 69.7).
- `a100_session2/out/battery8a100_qwen_fg/` — std tl0.8 fg edf_best 44.8 (S-tank, S30, pre-alpha-tuning).
- `a100_session2/out/battery8a100_wan_legacy/` — wan legacy short 11.3 / fg 7.5.
- `cost-model/{qwen-image,wan22-ti2v-5b}-a100/` — validated cost models (qwen 1/2/4/8). `*-newbox/` — reprofile validation.
- `workloads/` — all qwenbat8a100*/wanbat8a100* mixed-priority workloads.
- `gfc_a100_collective_bench.tgz` — GFC vs NCCL microbench.
- `*_driver.log`, `run_*.log` — orchestration logs.
