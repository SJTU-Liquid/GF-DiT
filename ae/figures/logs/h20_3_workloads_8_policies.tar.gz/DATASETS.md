# h20 mixed-priority scheduling battery

Hardware: NVIDIA H20 x4. Model: Wan-AI/Wan2.2-TI2V-5B-Diffusers. seed=42.

## Request classes (all 50 denoise steps; size scales by resolution+frames)
| class | role | resolution | frames | T_single(h20 SP1) | priority | preemptible | alpha |
|-------|------|-----------|--------|-------------------|----------|-------------|-------|
| S | foreground/urgent | 832x480  | 49 | ~56s  | 100 | no  | 2.0 |
| M | normal            | 832x480  | 81 | ~96s  | 50  | no  | 2.5 |
| L | background        | 1280x720 | 81 | ~268s | 0   | yes | 3.5 |
Deadlines: scheduler = arrival + alpha*T_single; client SLO check = +5000ms.

## Profiles (target-load calibrated so the best policy ~85-90%)
- short (1200s): warmup->midload->press ramp, S-heavy. tl=1.20, 61 (S40/M18/L3).
- foreground_burst (1800s): steady L background + two 85%-S bursts. tl=1.10, 65 (S38/M13/L14).
- inflight_burst (1500s): L fills SP4, quiet, then pure-S burst (no M). tl=0.90, 23 (S17/L6).
- tridentserve (3600s): 60-min dynamic mix. tl=1.09, 124 (S49/M49/L26). 8-policy INCOMPLETE (fcfs_* not run).

## Methods (rows in SUMMARY)
edf_greedy / edf_best_fit: deadline-aware, dynamic SP. Listed twice each -- (NCCL) and (GFC) migration backends.
srtf_spN / fcfs_spN: static-SP baselines, never migrate (NCCL only). sp1=4 SP1 lanes, sp2=2 SP2 lanes, sp4=1 SP4 group.

## Layout
SUMMARY.txt  per-profile table: SLO(overall,S,M,L) + latency(mean/p50/p95/p99) + qps, one row per method.
results_nccl/<profile>/sweep_<policy>_{result.json,bench.log,server.log}  (8 policies, 3 complete profiles)
results_gfc/<profile>/sweep_<edf_policy>_*  (edf_greedy/best_fit, GFC migration; incl tridentserve_GFC)
workloads/h20bat_<profile>_*.json
