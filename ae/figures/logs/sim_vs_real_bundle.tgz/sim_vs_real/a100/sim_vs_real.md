# Sim vs Real — a100 (8×A100)

SLO attainment %, `sim / real`. sim = idealized reshard=3ms baseline. `--` = real cell not run.

## QWEN short  (`qwenbat8a100_short_tl1.0_origalpha_seed42.json`)

| policy | S sim/real | M sim/real | L sim/real | overall sim/real |
|---|---|---|---|---|
| edf_best_fit | 100.0 /  77.7 | 100.0 /  72.0 | 100.0 /  69.2 | 100.0 /  75.3 |
| edf_greedy | 100.0 /  76.1 | 100.0 /  66.7 | 100.0 /  69.2 | 100.0 /  72.8 |
| srtf_sp1 |  73.1 /  65.0 |  57.0 /  48.4 | 100.0 /  96.2 |  70.6 /  62.7 |
| srtf_sp8 |   0.0 /   0.0 |   0.0 /   0.0 |   0.0 /   0.0 |   0.0 /   0.0 |
| fcfs_sp1 |  13.7 /  12.7 |  67.7 /  46.2 | 100.0 / 100.0 |  36.7 /  29.7 |
| legacy |   0.0 /   0.5 |   1.1 /   4.3 |   7.7 /  19.2 |   0.9 /   3.2 |

## QWEN fg  (`qwenbat8a100_fg_tl0.7_origalpha_seed42.json`)

| policy | S sim/real | M sim/real | L sim/real | overall sim/real |
|---|---|---|---|---|
| edf_best_fit |  95.6 /  68.1 |  95.6 /  81.6 | 100.0 /  87.2 |  96.5 /  74.2 |
| edf_greedy |  95.1 /  65.8 |  95.6 /  83.3 | 100.0 /  88.0 |  96.1 /  73.2 |
| srtf_sp1 |  51.4 /  47.8 |  77.2 /  68.4 | 100.0 /  96.6 |  65.3 /  60.8 |
| srtf_sp8 |   0.0 /   0.0 |  12.3 /  10.5 |   0.9 /   0.0 |   2.4 /   1.9 |
| fcfs_sp1 |  25.2 /  15.2 |  70.2 /  48.2 | 100.0 / 100.0 |  47.6 /  37.3 |
| legacy |   0.0 /   0.0 |   3.5 /   7.0 |  10.3 /  12.8 |   2.6 /   3.7 |

## WAN short  (`wanbat8a100_short_tl1.05_seed42.json`)

| policy | S sim/real | M sim/real | L sim/real | overall sim/real |
|---|---|---|---|---|
| edf_best_fit | 100.0 /  97.8 |  95.7 /  85.1 |  76.9 /  61.5 |  96.7 /  90.7 |
| edf_greedy | 100.0 /   --  |  95.7 /   --  |  76.9 /   --  |  96.7 /   --  |
| srtf_sp1 |  87.9 /  69.2 |  59.6 /  17.0 | 100.0 /   0.0 |  80.1 /  47.0 |
| srtf_sp8 |  25.3 /  48.4 |  10.6 /   8.5 |   0.0 /   0.0 |  18.5 /  31.8 |
| fcfs_sp1 |  30.8 /   7.7 |  70.2 /  23.4 | 100.0 / 100.0 |  49.0 /  20.5 |
| legacy |   6.6 /   7.7 |  17.0 /  19.1 |  38.5 /   7.7 |  12.6 /  11.3 |

## WAN fg  (`wanbat8a100_foreground_burst_tl0.9_seed42.json`)

| policy | S sim/real | M sim/real | L sim/real | overall sim/real |
|---|---|---|---|---|
| edf_best_fit |  86.7 /  86.7 |  85.7 /  82.1 | 100.0 / 100.0 |  89.4 /  88.8 |
| edf_greedy |  87.8 /   --  |  89.3 /   --  | 100.0 /   --  |  90.7 /   --  |
| srtf_sp1 |  59.2 /  72.4 |  85.7 /  78.6 | 100.0 / 100.0 |  72.7 /  79.5 |
| srtf_sp8 |   4.1 /  30.6 |  14.3 /  14.3 |   5.7 /   2.9 |   6.2 /  21.7 |
| fcfs_sp1 |  41.8 /  40.8 |  75.0 /  75.0 | 100.0 / 100.0 |  60.2 /  59.6 |
| legacy |   4.1 /   5.1 |  14.3 /  14.3 |  11.4 /   8.6 |   7.5 /   7.5 |
