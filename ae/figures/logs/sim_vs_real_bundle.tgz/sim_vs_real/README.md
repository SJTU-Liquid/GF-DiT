# Aligned simulator results — sim vs real (h20-4card & A100-8card)

Regenerated simulator runs aligned, paper口径, to the two **real** hardware
policy batteries, with a per-class (S/M/L) + overall SLO sim-vs-real comparison.

Driver: `benchmarks/diffusion/gen_sim_vs_real_grid.py` (copy included here as
`gen_sim_vs_real_grid.py`). Simulator: `runtime_v2_mixed_priority_runner.py`.
CPU-only; no GPU used to produce these sims.

## Alignment口径

The simulator consumes the **exact same workload JSON** the real serving run
replayed, so request arrivals, per-request deadlines, and target-load are
identical to real. Only the hardware-native cost model differs per box.

| | h20 campaign | A100 campaign |
|---|---|---|
| world_size | 4 | 8 |
| model(s) | Wan2.2-TI2V-5B | Qwen-Image (origalpha) + Wan2.2-TI2V-5B |
| cost model | `cost-model/wan22-ti2v-5b-h20` | `cost-model/qwen-image-a100`, `cost-model/wan22-ti2v-5b-a100` |
| profiles | short tl1.20, fg tl1.10, inflight tl0.90, tridentserve tl1.09 | qwen short tl1.0 / fg tl0.7; wan short tl1.05 / fg tl0.9 |

### Policy → simulator mapping
- **EDF (`edf_best_fit`, `edf_greedy`)**: full `sliding` topology, idealized
  `--reshard-ms 3.0`. This is the established optimistic sim baseline — the real
  per-migration cost (~tens–100 ms) is *not* modeled, so the sim<->real gap on
  EDF rows **is** the elastic-migration overhead the paper reports.
- **`srtf_spK` / `fcfs_spK`**: SRTF / FCFS ordering restricted via
  `--allowed-groups` to the SP-K lanes (sp1 = all single-rank lanes; sp2 = the
  non-overlapping pairs; sp4/sp8 = the full group). Mirrors how the real sweep
  pins fcfs/srtf to a groups-json. No migration → sim should track real exactly.
- **`srtf_sp8`** (A100): SRTF pinned to the single SP8 group (`--allowed-groups
  sp8`). Real file is `sweep_srtf_result.json` (the SUMMARY's "srtf_sp8" row).
- **`legacy`** (A100): SP8 FIFO baseline — FCFS pinned to the SP8 group. Real
  file is `legacy_sp8_result.json` (NOT `sweep_*`).

### SLO definition
- real: `per_class[k].slo_met / slo_defined` (serving result schema).
- sim:  `by_class[k].slo_attained / n` (simulator result schema).

## Validation (this regeneration reproduces the documented real numbers)
- **Static policies: sim ≈ real almost cell-for-cell** (no migration) — e.g. h20
  WAN-short `fcfs_sp2` 45.9/45.9, `fcfs_sp1` 55.7/54.1.
- **A100 reproduces the recorded real battery exactly**: qwen-short `edf_best`
  sim 100 / **real 75.3**, `srtf_sp1` 70.6 / **62.7**, `fcfs_sp1` 36.7 / **29.7**,
  `srtf_sp8` 0.0 / **0.0**, `legacy` 0.9 / **3.2**; wan-short `edf_best`
  **sim 96.7 / real 90.7** (recorded −6pp); wan-fg `legacy` 7.5 / **7.5**.
- **EDF is systematically over-predicted by the migration-overhead gap**: h20
  ~2–5pp, A100 wan ~6pp, **A100 qwen ~22–25pp** (the elastic SP-switch migration
  cost, worst on the 8-GPU high-throughput qwen-image regime).

## Files
- `h20/sim_vs_real.md`, `a100/sim_vs_real.md` — the comparison tables.
- `h20/sim_vs_real.csv`, `a100/sim_vs_real.csv` — flat (row,policy,scope,sim,real).
- `h20/grid.json`, `a100/grid.json` — per-cell sim + real SLO + real result path.
- `<campaign>/sim/<workload>__<policy>.json` — raw simulator result per cell
  (full overall + by_class + per_request).

## Provenance of the REAL side (compared against, not included here)
- h20-4card real: `out/h20battery/` on the h20 box (`H20-2`), pulled
  2026-06-05; 8 policies × 4 profiles (tridentserve: edf+srtf only).
- A100-8card real: local `out/a100_session2/out/battery8a100_qwen_origalpha/`
  (qwen) and `out/wan_a100_bundle/out/battery8a100_wan_*` (wan); `legacy_sp8`
  rows extracted from `out/a100_full_benchmark.tgz` into
  `out/a100_session2/out/battery8a100_{qwen_origalpha,wan_legacy}/`; also archived
  in `out/qwen_origalpha_complete.tgz`. The vast.ai A100 box is released.

## Caveats
- A100 real did not run `edf_greedy` for WAN (only `edf_best_fit`); those cells
  show `--` on the real side.
- `srtf_sp8` on WAN: sim under-predicts real (wan-short 18.5 / 31.8, wan-fg 6.2 /
  21.7) — the cost model's wan SP8 floor is more pessimistic than real for this
  degenerate single-group baseline. qwen `srtf_sp8` matches exactly (0.0/0.0,
  2.4/1.9), and `legacy` matches well on both models.
- h20 EDF elastic topology in sim is the runner's `sliding` set (the established
  convention), not the exact production autotune group list.
