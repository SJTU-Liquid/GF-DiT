# Aligned sim-vs-real — fixing the SRTF request_id tie-break artifact

This bundle re-runs the sim side of the `sim_vs_real` grid with **one change**:
the simulator's workload `request_id`s are md5-randomized. Everything else
(policies, cost models, topology `sliding`, `--reshard-ms 3.0`, world size, the
exact real result files) is identical to `out/sim_vs_real/`.

## Why (root cause of the old srtf misalignment)

`SRTFSchedulerPolicy._select_shortest_request` breaks ties — equal
`remaining_work`, e.g. a backlog of fresh same-class requests — by the
**`request_id` string**: `key = (remaining_work, active?, request_id)`.

- **Stock workloads use ordered ids** (`S_000000, S_000001, …` in arrival
  order) ⇒ the tie-break degrades to **FIFO** within a priority class ⇒ fair,
  no starvation.
- **Real serving assigns random uuids** (`video_gen_<hex>`) ⇒ the tie-break is
  **random** ⇒ some early-arriving requests are repeatedly bypassed by
  smaller-uuid ones ⇒ **starvation tail** (a few requests wait 3–10×).

So the ordered-id sim did **not** model the real scheduler. The mismatch is
worst on the **single-wide-lane** rows (`srtf_sp4`, A100 `srtf_sp8`) where every
request serializes through one queue, so the tie-break fully determines order.

This was verified end-to-end with a traced real run (h20 GPUs 1,2,5,7, full
scheduler trace): both sim and real run srtf_sp4 effectively non-preemptively
(run-to-completion), with matching service order/durations and a strictly serial
lane — the ONLY behavioral difference was the id tie-break. Randomizing the sim
ids reproduces the real latency distribution (starvation tail, and the whole
S-deadline sweep a2.0/2.5/3.0/4.0).

## Effect (h20 WAN, overall SLO %, sim → aligned-sim vs real)

| row | policy | old sim | **aligned sim** (seed0 / seed mean±std) | real |
|---|---|---|---|---|
| short | srtf_sp4 | 54.1 | **67.2** / 65.3±1.1 | 67.2 |
| short | srtf_sp1 | 73.8 | 80.3 / 79.5±1.3 | 82.0 |
| fg | srtf_sp4 | 49.2 | 55.4 / 59.0±1.9 | 58.5 |
| inflight| srtf_sp4 | 60.9 | 65.2 / 65.2±4.3 | 65.2 |
| trident | srtf_sp4 | 74.2 | 76.6 / 75.4±1.5 | 74.2 |

`srtf_sp4` mean |sim−real| drops from ~6.7pp to ~1.0pp. **`fcfs_*` rows are
unchanged** (FCFS orders by arrival, not id → already aligned, stays
cell-for-cell), confirming the id only moves SRTF. **`edf_*` rows are unchanged**
— their residual offset is the *real* elastic-migration overhead (sim uses ideal
`reshard=3ms`), a separate effect the id fix does not and should not touch.

## Caveats / honesty

- **Single-lane vs multi-lane.** The fix is cleanest for `srtf_sp4` / `srtf_sp8`
  (one serial queue → max tie-break sensitivity). Multi-lane `srtf_sp1`
  (N independent lanes) distributes load, so the effect is smaller and within
  run-to-run noise — a couple of `srtf_sp1` cells move a few pp in either
  direction. Treat those as noise, not signal.
- **Statistical, not cell-identical, alignment.** Sim uses a *random* id
  permutation (md5 seed 0 in the table); real used its own random uuids. They
  match in *distribution* (same random tie-break), not request-for-request,
  hence the seed mean±std column (6 seeds) — read it as the aligned estimate.
- The deeper takeaway: **real has a genuine starvation bug** — SRTF should
  tie-break by arrival/submission order (FCFS-within-equal-priority), which
  removes the tail (what the ordered-id sim accidentally does right) and is
  strictly better at non-tight deadlines. Not fixed here (real not re-run); the
  alignment instead matches the sim to real's current behavior.
- Not a failures artifact: the traced real run had **0 failed requests, 61/61
  completed, every request ran the full 50 DiT steps** (so nothing was "kicked
  out" to free the lane).

## Files

- `<camp>/sim_vs_real.md` / `.csv` / `grid.json` — aligned tables (seed 0 cells +
  per-srtf-row seed mean±std).
- `<camp>/sim/<wl>__<policy>__seed<k>.json` — raw aligned sim results.
- `<camp>/randwl/<wl>__seed<k>.json` — the md5-id workload copies fed to the sim.
- `gen_sim_vs_real_aligned.py` — the regenerator (imports the stock grid driver's
  helpers verbatim; only swaps in randomized ids).

## Reproduce

    PYTHONPATH=. .venv/bin/python benchmarks/diffusion/gen_sim_vs_real_aligned.py \
        --campaign h20 --seeds 6 --jobs 12 --out-dir out/sim_vs_real_aligned

## Provenance / config-alignment proof

Identical sim config to `out/sim_vs_real/` (verified): (1) the randomized
workload differs from the original in **exactly one field, `request_id`**
(arrival_ms, deadline_ms, num_steps, latent_seq_len, request_class, sizes all
identical); (2) re-running with the *original* ids reproduces the stored grid
sim cell-for-cell (h20 srtf_sp4 short: S 25/40, M 7/18, L 1/3 → 54.1%); (3) same
command (`make_srtf`, cost `wan22-ti2v-5b-h20`, `--topology-style sliding`,
world 4, `--reshard-ms 3.0`, `--allowed-groups sp4`).
