# GFC vs NCCL collective microbenchmark — H20 ×4 (world=4), CUDA-graph pure-GPU

Same method as the A100 bundle: `bench_symm_collectives.py`, dtype=bf16,
`--cuda-graph 1 --graph-nccl-reference 1 --graph-batch-iters 10 --iters 15 --warmup 3`
(both GFC and NCCL graph-captured). One fresh process per (collective,size).
GPUs 1-4 (GPU0 was busy → excluded). GFC commit 150f3d2. Date 2026-05-31.
Ratio = GFC/NCCL (>1 = GFC slower, <1 = GFC faster).

## all2all  (per-rank bytes | GFC lat us | NCCL us | GFC/NCCL)
| 1Ki | 11.0 | 10.6 | 1.00 |
| 2Ki | 11.0 | 7.9 | 1.36 |
| 4Ki | 11.0 | 8.0 | 1.34 |
| 8Ki | 11.0 | 8.0 | 1.34 |
| 16Ki | 11.0 | 8.5 | 1.26 |
| 32Ki | 11.7 | 9.2 | 1.17 |
| 64Ki | 11.2 | 9.1 | 1.20 |
| 128Ki | 11.5 | 10.5 | 1.06 |
| 256Ki | 12.4 | 12.3 | 0.98 |
| 512Ki | 13.2 | 11.2 | 1.15 |
| 1Mi | 14.9 | 14.9 | 0.98 |
| 2Mi | 18.6 | 23.4 | 0.79 |
| 4Mi | 25.0 | 24.2 | 1.02 |
| 8Mi | 36.2 | 38.2 | 0.93 |
| 16Mi | 62.7 | 65.2 | 0.96 |
| 32Mi | 115.0 | 114.3 | 1.00 |
| 64Mi | 209.5 | 199.5 | 1.05 |

## allgather  (per-rank bytes | GFC lat us | NCCL us | GFC/NCCL)
| 1Ki | 11.0 | 8.3 | 1.39 |
| 2Ki | 11.0 | 11.4 | 0.94 |
| 4Ki | 11.1 | 9.5 | 1.13 |
| 8Ki | 11.0 | 10.0 | 1.08 |
| 16Ki | 11.2 | 10.9 | 1.00 |
| 32Ki | 11.5 | 10.0 | 1.12 |
| 64Ki | 12.3 | 10.0 | 1.20 |
| 128Ki | 13.0 | 11.5 | 1.10 |
| 256Ki | 14.6 | 14.1 | 1.02 |
| 512Ki | 18.6 | 19.5 | 0.94 |
| 1Mi | 24.1 | 36.5 | 0.65 |
| 2Mi | 34.2 | 45.6 | 0.74 |
| 4Mi | 53.8 | 64.0 | 0.83 |
| 8Mi | 96.3 | 105.9 | 0.90 |
| 16Mi | 178.7 | 191.5 | 0.93 |
| 32Mi | 338.9 | 348.6 | 0.97 |
| 64Mi | 660.8 | 664.3 | 0.99 |

## Takeaways (vs A100 8-card bundle)
- GFC small-msg floor on H20 4-card is **~11us** (kernel≈latency), vs **~25us** on A100 8-card.
  Fewer ranks + H20 symm-mem path → much lower barrier floor. So GFC's small-msg standing
  vs NCCL is far better here than the A100 8-card table suggested.
- all2all: small (≤16Ki) GFC ~1.0-1.36x NCCL (NCCL's tiny-msg ~8us is hard to beat); crossover
  ~1-2Mi; GFC wins 2Mi (0.79), ties large.
- allgather: GFC ties small, **clearly wins mid (1Mi 0.65, 2Mi 0.74, 4Mi 0.83)**, converges large.
- latency p50 ≈ kernel_time p50 within ~0.5us everywhere → clean graph measurement.
