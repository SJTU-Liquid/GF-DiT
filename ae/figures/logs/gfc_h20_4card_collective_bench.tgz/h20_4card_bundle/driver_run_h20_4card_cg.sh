#!/bin/bash
set -u
cd /home/LOCAL/shixuan/xinwei/GroupFree-Collective
export LD_LIBRARY_PATH="" HF_HUB_OFFLINE=1 CUDA_VISIBLE_DEVICES=1,2,3,4
TR=/home/LOCAL/shixuan/xinwei/.venv/bin/torchrun
SIZES="1024 2048 4096 8192 16384 32768 65536 131072 262144 524288 1048576 2097152 4194304 8388608 16777216 33554432 67108864"
echo "START world=4 cudagraph batch10/w3/i15  $(date)"
for coll in all2all allgather; do
  echo "## $coll"
  for b in $SIZES; do
    o=$($TR --standalone --nproc_per_node=4 benchmarks/bench_symm_collectives.py \
        --collective "$coll" --bytes "$b" --dtype bf16 \
        --cuda-graph 1 --graph-nccl-reference 1 --graph-batch-iters 10 \
        --iters 15 --warmup 3 --compare-nccl-reference 2>/dev/null)
    lat=$(echo "$o" | grep -oP 'latency\s+p50=\K[0-9.]+')
    ker=$(echo "$o" | grep -oP 'kernel_time\s+p50=\K[0-9.]+')
    ncl=$(echo "$o" | grep -oP 'nccl_reference\s+p50=\K[0-9.]+')
    rat=$(echo "$o" | grep -oP 'ratio \K[0-9.]+')
    printf '%s bytes=%s GFC_lat=%s GFC_ker=%s NCCL=%s gfc/nccl=%s\n' "$coll" "$b" "${lat:-NA}" "${ker:-NA}" "${ncl:-NA}" "${rat:-NA}"
  done
done
echo "=== DONE $(date) ==="
