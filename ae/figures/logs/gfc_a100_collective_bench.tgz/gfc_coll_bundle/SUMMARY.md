# GFC vs NCCL collective microbenchmark — A100-SXM4-80GB ×8 (NV12 full NVLink)

world=8, dtype=bf16. Tool: `GroupFree-Collective/benchmarks/bench_symm_collectives.py`
(`--compare-nccl-reference`; both GFC and NCCL measured the same way per method).
GFC timed on `runtime.stream`; NCCL on its own stream. Each run is its OWN process
(no cross-size epoch carryover). MUST run alone — concurrent jobs contaminate timings
(a contended run gave bogus ~8800us; clean run gave ~25us).

## Three measurement methods (all2all, representative per-rank sizes)

| size | eager(launch incl) GFC/NCCL | eager+sleep(launch hidden) GFC/NCCL | cudagraph(pure GPU) GFC/NCCL |
|---|---|---|---|
| 16 KiB | 167 / 59 us | 166 / 25 us | 25 / 16 us |
| 1 MiB  | 171 / 82 us | 170 / 49 us | 34 / 38 us |
| 16 MiB | 242 / 178 us| 241 / 145 us| 125 / 131 us|

- **eager** (`--cuda-graph 0`, per-iter start/stop): includes CPU launch + host work. = serving reality per call.
- **eager+sleep** (`torch.cuda._sleep` before a batched timed loop, Triton-distributed style):
  hides async LAUNCH latency. NCCL drops 59->25us (launch was ~34us). **GFC does NOT drop
  (167->166us)** -> GFC's ~140us is NOT async launch; it is *synchronous host-side work*
  (symm-mem signaling / epoch / host barrier between kernels) that a sleep cannot hide.
- **cudagraph** (`--cuda-graph 1` + `--graph-nccl-reference 1`): captures the kernel
  sequence once; replay = pure GPU time. Removes both launch and the host sync.
  GFC ~25us, NCCL ~16us at small.

### Conclusion
GFC's GPU kernels are competitive with NCCL (see full sweep below). GFC's eager
per-call cost (~165us small) is dominated by **synchronous host-side work** (~140us),
NOT GPU exec (~25us) and NOT async launch (sleep would hide it; it does not). cudagraph
removes it. Serving uses eager (elastic SP precludes cudagraph), so it pays this host
sync every collective -> this is the dispatch/low-GPU-util bottleneck seen in serving.
Fix direction: cut GFC's per-call synchronous host work.

## Full cudagraph pure-GPU sweep (batch10 / warmup3 / iter15, both graph-captured)

### all2all  (per-rank bytes | GFC us | NCCL us | GFC/NCCL)
| 1Ki | 25.1 | 16.5 | 1.52 |
| 2Ki | 25.0 | 16.6 | 1.51 |
| 4Ki | 25.2 | 16.0 | 1.57 |
| 8Ki | 24.9 | 16.0 | 1.56 |
| 16Ki | 25.4 | 21.4 | 1.19 |
| 32Ki | 25.6 | 16.8 | 1.52 |
| 64Ki | 24.9 | 23.1 | 1.08 |
| 128Ki | 25.9 | 18.9 | 1.37 |
| 256Ki | 26.7 | 25.5 | 1.05 |
| 512Ki | 29.5 | 26.2 | 1.13 |
| 1Mi | 33.6 | 38.0 | 0.88 |
| 2Mi | 38.9 | 48.5 | 0.80 |
| 4Mi | 50.4 | 83.0 | 0.61 |
| 8Mi | 73.3 | 89.7 | 0.82 |
| 16Mi | 124.8 | 130.9 | 0.95 |
| 32Mi | 216.8 | 216.3 | 1.00 |
| 64Mi | 397.8 | 368.2 | 1.08 |

### allgather
| 1Ki | 25.0 | 19.0 | 1.32 |
| 2Ki | 25.4 | 25.2 | 1.01 |
| 4Ki | 25.1 | 25.6 | 0.98 |
| 8Ki | 27.0 | 27.0 | 1.00 |
| 16Ki | 26.0 | 27.2 | 0.96 |
| 32Ki | 27.0 | 32.2 | 0.84 |
| 64Ki | 29.4 | 27.6 | 1.07 |
| 128Ki | 32.3 | 33.5 | 0.96 |
| 256Ki | 38.0 | 43.6 | 0.87 |
| 512Ki | 51.0 | 68.6 | 0.74 |
| 1Mi | 68.7 | 95.3 | 0.72 |
| 2Mi | 105.3 | 214.5 | 0.49 |
| 4Mi | 183.5 | 256.4 | 0.72 |
| 8Mi | 331.3 | 392.3 | 0.84 |
| 16Mi | 627.1 | 661.3 | 0.95 |
| 32Mi | 1209.1 | 1226.3 | 0.99 |
| 64Mi | 2388.1 | 2329.5 | 1.03 |

**Pure-GPU takeaway:** all2all — GFC has a ~25us small-msg floor (1.5x NCCL), ties/beats
at 1-8Mi (0.61-0.88x), ties at large. allgather — GFC ~= NCCL small, clearly faster
mid (2Mi 0.49x!), ties large. GFC's GPU kernel is NOT the problem.

## Notes / repro
- bench_symm_collectives.py `_bench_kernel_time` was patched to add the sleep+batched
  eager timing (Triton-distributed `torch.cuda._sleep`); cudagraph path unchanged.
  Original backed up on A100 at /tmp/bench_symm_orig.py.
- Run ONE bench at a time on idle GPUs. warmup1/iter2 is enough ONLY on a fully idle
  box with cudagraph; for non-cudagraph use warmup>=3 to clear cold-start.
- batch >= 10 amortizes; batch64 also fine but the user preferred 10.
